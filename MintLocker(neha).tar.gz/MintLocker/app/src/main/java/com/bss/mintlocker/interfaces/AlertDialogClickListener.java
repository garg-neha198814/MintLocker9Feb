package com.bss.mintlocker.interfaces;

import android.support.v7.app.AlertDialog;

/**
 * Created by deepakgoyal on 19/11/15.
 */
public interface AlertDialogClickListener {

    public void cancelButton();
    public void okButton();
}
