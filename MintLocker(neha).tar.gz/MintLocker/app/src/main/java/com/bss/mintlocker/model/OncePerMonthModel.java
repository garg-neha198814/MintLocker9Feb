package com.bss.mintlocker.model;

/**
 * Created by bhawanisingh on 19/11/15.
 */
public class OncePerMonthModel {

    private int noofday;

    public OncePerMonthModel(int noofday) {
        this.noofday = noofday;
    }

    public int getNoofday() {
        return noofday;
    }

    public void setNoofday(int noofday) {
        this.noofday = noofday;
    }
}
