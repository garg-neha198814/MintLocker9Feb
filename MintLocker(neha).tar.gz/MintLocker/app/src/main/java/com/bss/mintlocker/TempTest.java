package com.bss.mintlocker;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by bhawanisingh on 20/12/15.
 */
public class TempTest extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.temptest);


    }



}
