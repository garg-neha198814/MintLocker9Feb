package com.bss.mintlocker.interfaces;

/**
 * Created by deepakgoyal on 19/11/15.
 */
public interface DateSelectedInterface {
    public void onDateSet(String date);
}
